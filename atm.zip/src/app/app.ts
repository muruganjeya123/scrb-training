import { Component, input, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Withdraw } from './withdraw/withdraw';
import { Calculator } from "./calculator/calculator";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Withdraw, Calculator],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
display: any;
  navigateTo(value:string){
   this.display = value;
this.display = `Withdrawing ${value}`;
     
  }
  promptAmount(value:string){
    
     this.display = value;
  this.display=`Amount entered is: ${value}`;
    
  }
  updateDisplay(value:string){
    this.display = value;
    this.display = `Amount entered is: ${value}`;
  }}
