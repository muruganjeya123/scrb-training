import { Component } from '@angular/core';

@Component({
  selector: 'app-withdraw',
  imports: [],
  templateUrl: './withdraw.html',
  styleUrl: './withdraw.css',
})
export class Withdraw {
  withdraw(amount: number): void {
    document.body.innerHTML += `<p>Withdrawing $${amount}</p>`;

  
  }

}
