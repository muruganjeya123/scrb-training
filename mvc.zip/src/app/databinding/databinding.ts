import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-databinding',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './databinding.html',
  styleUrl: './databinding.css',
})
export class Databinding {
  name= 'jeyamurugan';

  isdisabled= true;

  enable(){
    this.isdisabled= false;
  }
  
  username= '';
  showalert(){
    alert('welcome '+ this.username);
  }}