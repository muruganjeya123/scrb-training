package exception;

public class demo2 {
	public static void main(String[] args) {
		int a[]= {10,30,46};
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		try {
			System.out.println(a[3]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("i am from catch " +e);
		}
		System.out.println("hello");
		System.out.println("hello");
		try {
			System.out.println(10/0);
		} catch (ArithmeticException e1) {
			System.out.println("i am from catch "+e1);
		}
		
		System.out.println("hello");
		System.out.println("hello");
		System.out.println("hello");
	}

}
