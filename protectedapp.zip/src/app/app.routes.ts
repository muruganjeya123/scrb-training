import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard';

export const routes: Routes = [
  { path: 'chat', component: DashboardComponent },
  { path: '', redirectTo: '/chat', pathMatch: 'full' }
];