import { Component, Input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Chat } from '../chat';

@Component({
  selector: 'app-chat-box',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="chat-container">
      <h3>{{ userName }}</h3>
      <div class="message-list">
        <div *ngFor="let msg of chatService.getMessages()" 
             [ngClass]="{'my-msg': msg.sender === userName, 'other-msg': msg.sender !== userName}">
          <small>{{ msg.sender }}</small>
          <p>{{ msg.text }}</p>
        </div>
      </div>
      <input [(ngModel)]="newMsg" (keyup.enter)="send()" placeholder="Type...">
      <button (click)="send()">Send</button>
    </div>
  `,
  styles: [`
    .chat-container { width: 250px; border: 2px solid #333; margin: 10px; border-radius: 10px; padding: 10px; background: #eee; }
    .message-list { height: 200px; overflow-y: auto; background: white; padding: 5px; margin-bottom: 10px; }
    .my-msg { text-align: right; color: blue; }
    .other-msg { text-align: left; color: green; }
    input { width: 70%; }
  `]
})
export class ChatBoxComponent {
  @Input() userName: string = '';
  chatService = inject(Chat);
  newMsg: string = '';

  send() {
    if (this.newMsg.trim()) {
      this.chatService.addMessage(this.userName, this.newMsg);
      this.newMsg = '';
    }
  }
}