import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Chat {
  messages: { sender: string, text: string }[] = [
    { sender: 'System', text: 'Welcome to the Group Chat!' }
  ];

  addMessage(sender: string, text: string) {
    this.messages.push({ sender, text });
  }

  getMessages() {
    return this.messages;
  }
  
}
