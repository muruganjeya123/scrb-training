import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <header style="background: #333; color: white; padding: 10px; text-align: center;">
      <h1>My Protected Chat App</h1>
    </header>
    <router-outlet></router-outlet>
  `
})
export class AppComponent {}