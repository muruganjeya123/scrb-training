import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatBoxComponent } from '../chat-box/chat-box';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, ChatBoxComponent],
  template: `
    <div style="text-align: center;">
      <h2>Group Chat (3 Members)</h2>
      <div style="display: flex; justify-content: center; flex-wrap: wrap;">
        <app-chat-box userName="Arul"></app-chat-box>
        <app-chat-box userName="Kumar"></app-chat-box>
        <app-chat-box userName="Priya"></app-chat-box>
      </div>
    </div>
  `
})
export class DashboardComponent {}