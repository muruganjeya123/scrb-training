import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { RoomAC } from "./room-ac/room-ac";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RoomAC],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('depinj');
}
