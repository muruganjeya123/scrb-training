import { Component } from '@angular/core';
import { ACservice } from '../acservice';

@Component({
  selector: 'app-room-ac',
  imports: [],
  templateUrl: './room-ac.html',
  styleUrl: './room-ac.css',
})
export class RoomAC {
  message: string = '';
  temp: number = 24;
  constructor(private acservice: ACservice) {}
  ONac() {
    this.message = this.acservice.turnonAC();
  }
  OFFac() {
    this.message = this.acservice.turnoffAC();
  }
  changeTemp(degree: number) {
    this.temp = this.temp + degree;

}}
