import { TestBed } from '@angular/core/testing';

import { ACservice } from './acservice';

describe('ACservice', () => {
  let service: ACservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ACservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
