import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ACservice {
  turnonAC() {
    return 'AC is turned ON';
  }
  turnoffAC() {
    return 'AC is turned OFF';
  }
  
}
