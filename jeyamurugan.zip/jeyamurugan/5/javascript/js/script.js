function helo() {
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    if (username=="indiaa") {
        alert("username correct");
        }
    else{
    alert("username wrong")
        }
        
    if (username=="indiaa" && password=="hello") {
        alert("password correct");
        window.location.href="backround.html";        return false;
        
    }
    else{
    alert("please check your username and password")
     }
}