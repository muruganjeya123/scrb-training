function validateform() {
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    if (username=="kumar") {
        alert("username correct");
        
         }
    else{
    alert("username wrong")
        }
    if (username=="kumar" && password=="kumar@123") {
        alert("password correct");
        window.location.href="student.html";
        return false;
        
    }
    else{
    alert("password wrong")
     }
}