import { Injectable } from '@angular/core';
import { Student } from '../../student';

@Injectable({
  providedIn: 'root',
})
export class Studentservice {
  private students: Student[] = [
    { id: 1, name: 'Alice', age: 20, grade: 'A' },
    { id: 2, name: 'Bob', age: 22, grade: 'B' },
    { id: 3, name: 'Charlie', age: 21, grade: 'C' },
  ];
  constructor() {}

  getStudents(): Student[] {
    return this.students;
  }
  addStudent(student: Student): void {
    this.students.push(student);
  }
  updateStudent(id: number, updatedStudent: Student): void {
    const index = this.students.findIndex((s) => s.id === id);
    if (index !== -1) {
      this.students[index] = updatedStudent;
    }
  }
  deleteStudent(id: number): void {
    this.students = this.students.filter((s) => s.id !== id);
  }}
