import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Student } from '../student';
import { Studentservice } from './services/studentservice';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('http-method-demo');
students: Student[] = [];
constructor(private studentService: Studentservice) {
  this.ngOnInit();
}
  ngOnInit() {
      this.getAllStudents();
  }
  // GET
  getAllStudents() {
    this.students = this.studentService.getStudents();
  }

addStudent() {
  const student: Student = {
    id: 4,
    name: 'David',
    age: 23,
    grade: 'A'
  };
      this.studentService.addStudent(student);
    this.getAllStudents();
  }
  //put
  updateStudent() {
    const updatedStudent: Student = {
      id: 2,
      name: 'Bob Updated',
      age: 22,
      grade: 'A'
    };
    this.studentService.updateStudent(2, updatedStudent);
    this.getAllStudents();
  } 
  //delete
  deleteStudent() {
    this.studentService.deleteStudent(3);
    this.getAllStudents();  
}

}