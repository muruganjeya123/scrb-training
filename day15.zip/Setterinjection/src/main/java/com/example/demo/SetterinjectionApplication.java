package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SetterinjectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SetterinjectionApplication.class, args);
	}

}
