package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CarController {
	public Car car;
	public CarController (Car car) {
		this.car=car;
		
	}
	@GetMapping("/jeya")
	public String drivecar() {
		return car.drive();
	}
	


}
