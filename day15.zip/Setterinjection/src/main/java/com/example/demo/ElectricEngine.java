package com.example.demo;

import org.springframework.stereotype.Component;

@Component("electric")
class ElectricEngine implements Engine3 {
    public String start() { return "Whirrr! Electric Engine started."; }
}
