package com.example.demo;

import org.springframework.stereotype.Component;

@Component("gas")

public class GasEngine implements Engine3 {
    public String start() { return "Vroom! Gas Engine started."; }
}