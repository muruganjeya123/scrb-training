package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Car {
	public GasEngine engine;
	
	public Car(@Qualifier("gas") GasEngine engine) {
        this.engine = engine;
    }


	public String drive() {
		return engine.start();
		
	}

}
