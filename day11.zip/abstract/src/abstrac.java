

abstract class Abcd
{
    abstract  void m1() ;
}

public class abstrac extends Abcd {
	void m1()
	{
		System.out.println("method m1");
	}

public static void main(String[] args) {
	abstrac  xy = new abstrac();
   xy.m1();

	
}
}
