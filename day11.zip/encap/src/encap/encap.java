package encap;
class math{
	int b;
	int a=80;
}

public class encap extends math{
	
	void add(int a) {
		System.out.println("i am from method "+a);
		System.out.println("i am from method "+this.a);
		
	}
	void xyz() {
		int b=20;
		this.b=b;
		System.out.println("i am from xyz "+this.b);
		System.out.println("i am from xyz "+b);
		
	}

	public static void main(String[] args) {
		encap ss=new encap();
		ss.add(20);
		ss.xyz();

	}

}
