package calc;

public class calc {
	static float a=5, b= 10;
	void add() {
		float c=a+b;
		System.out.println(c);
	}
	void sub() {
		float c=a-b;
		System.out.println(c);
	}void mul() {
		float c=a*b;
		System.out.println(c);
	}
	void div() {
		float c=a/b;
		System.out.println(c);
	}




	public static void main(String[] args) {
		calc a=new calc();
		a.add();
		a.sub();
		a.mul();
		a.div();
		

	}

}
