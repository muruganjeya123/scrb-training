
class grandfather{
void suger(){
	 System.out.println("hello i have suger");
	}}
class father extends grandfather{
void bp(){
	 System.out.println("hello i have BP");
	}}
public class multi extends father {
	

	public static void main(String[] args) {
		multi tj=new multi();
		tj.suger();
		tj.bp();
		// TODO Auto-generated method stub

	}

}
