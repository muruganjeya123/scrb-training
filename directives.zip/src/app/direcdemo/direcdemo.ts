import { Component } from '@angular/core';

@Component({
  selector: 'app-direcdemo',
  imports: [],
  templateUrl: './direcdemo.html',
  styleUrl: './direcdemo.css',
})
export class Direcdemo {
  name="jeyamurugan";
  course="angular training";
  fees=25000;

}
