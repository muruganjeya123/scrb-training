import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Direcdemo } from './direcdemo';

describe('Direcdemo', () => {
  let component: Direcdemo;
  let fixture: ComponentFixture<Direcdemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Direcdemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Direcdemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
