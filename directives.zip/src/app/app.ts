import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Direcdemo } from "./direcdemo/direcdemo";
import { Structuraldir } from "./structuraldir/structuraldir";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Direcdemo, Structuraldir],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('directives');
}
