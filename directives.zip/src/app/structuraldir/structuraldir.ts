import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-structuraldir',
  imports: [CommonModule],
  templateUrl: './structuraldir.html',
  styleUrl: './structuraldir.css',
})
export class Structuraldir {

isloggedin=false;
login(){
  this.isloggedin=true;
}
logout(){
  this.isloggedin=false;
}

courses:string[]=["angular","reactjs","vuejs","nodejs","python"];

color:string="";
setcolor(col:string){
  this.color=col;

}}